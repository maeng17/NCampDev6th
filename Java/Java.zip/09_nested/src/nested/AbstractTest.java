package nested;

public abstract class AbstractTest { //POJO
	String name;

	public String getName() {
		return name;
	}

	public abstract void setName(String name); //추상메소드
		
	
	

}
