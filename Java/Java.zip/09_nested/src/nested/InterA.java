package nested;

public interface InterA {
	public void aa();
	public void bb();

}
