package nested;

public abstract class AbstractExam {
	public void cc() {} //빈 body
	public void dd() {} //빈 body
	
}
