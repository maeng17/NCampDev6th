package homework;

public class MemberMain01 {

	public static void main(String[] args) {
		MemberService01 ms = new MemberService01();
		ms.menu(); // 호출
		System.out.println("프로그램을 종료합니다.");

	}

}
