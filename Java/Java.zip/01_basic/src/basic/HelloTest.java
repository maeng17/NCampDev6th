package basic;

public class HelloTest {

	public static void main(String[] args) {
		System.out.println("안녕하세요:)");
	}

}
