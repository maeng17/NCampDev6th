package com.zoo;

public class Zoo2 {
	public static void main(String[] args) {
		Zoo z = new Zoo();
		z.tiger();
		z.giraffe(); 
		z.elephant(); 
		//z.lion(); -error

	}
}
