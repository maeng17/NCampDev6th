package com.zoo;

public class Zoo {
	
	public void tiger() {
		System.out.println("무서운 호랑이");
	}
	
	protected void giraffe() {
		System.out.println("목이 긴 기린");
	}
	void elephant() {
		System.out.println("뚱뚱한 코끼리");
	}
	private void lion() {
		System.out.println("멋진 사자");
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
