package interface_;

public interface InterC extends InterA, InterB {

}
