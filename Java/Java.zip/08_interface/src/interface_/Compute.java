package interface_;

public interface Compute {
	public void disp(); //추상메소드

}
