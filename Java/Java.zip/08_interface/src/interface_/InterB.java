package interface_;

public interface InterB {
	public void cc();
	public void dd();
	
	

}
