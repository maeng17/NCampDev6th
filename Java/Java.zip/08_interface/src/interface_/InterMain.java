package interface_;

// public class InterMain implements InterA, InterB {
public class InterMain implements InterC {

	public void aa() {}
	public void bb() {}
	
	public void cc() {}
	public void dd() {}
	
	
	
	public static void main(String[] args) {

	}

}
