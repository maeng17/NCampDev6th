package interface_;

public interface InterA {
	public static final String NAME = "홍길동"; //상수
	public int AGE = 25;
	
	public abstract void aa(); //추상메소드
	public void bb();
}
