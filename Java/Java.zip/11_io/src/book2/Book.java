package book2;

import java.util.List;

public interface Book {
	public void execute(List<BookDTO> list); // 추상 메소드
}
