package com.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SumDTO {
	private int x;
	private int y;

}
