package user.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserImageDTO {
	private int seq;
	private String imageName;
	private String imageContent;
	private String image1;
}
