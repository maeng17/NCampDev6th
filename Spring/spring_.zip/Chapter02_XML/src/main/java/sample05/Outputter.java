package sample05;

public interface Outputter {
	public void output(String message);
}
