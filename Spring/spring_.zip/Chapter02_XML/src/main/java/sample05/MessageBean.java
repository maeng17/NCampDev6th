package sample05;

public interface MessageBean {
	public void helloCall();
}
