package sample04;

public interface Calc {
	public void calculate(int x, int y);

}
