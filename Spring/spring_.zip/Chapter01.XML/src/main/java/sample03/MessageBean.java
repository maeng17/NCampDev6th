package sample03;

public interface MessageBean {
	public void sayHello(String name); //추상 메소드
}
