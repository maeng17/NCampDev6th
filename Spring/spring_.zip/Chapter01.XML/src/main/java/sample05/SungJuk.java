package sample05;

public interface SungJuk {
	public void calc();
	public void display();

}
