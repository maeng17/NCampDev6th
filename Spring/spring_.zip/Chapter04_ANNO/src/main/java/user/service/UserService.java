package user.service;

public interface UserService {
	public void execute();
}
