package sample02;

public interface Calc {
	public void calculate();
}
