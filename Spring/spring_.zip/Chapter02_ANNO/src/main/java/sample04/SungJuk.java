package sample04;

public interface SungJuk {
	public void execute();

}
